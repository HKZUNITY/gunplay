﻿export enum EventType {
    /**
     * 打开关闭（主控和雷达UI）
     */
    OpenCloseHUDRadarUI = "OpenCloseHUDRadarUI",
}