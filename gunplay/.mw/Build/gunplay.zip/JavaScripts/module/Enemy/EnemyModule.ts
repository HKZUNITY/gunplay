﻿export class EnemyModuleC extends ModuleC<EnemyModuleS, null> {
    protected onStart(): void {

    }

}

export class EnemyModuleS extends ModuleS<EnemyModuleC, null> {

    protected onStart(): void {

    }

}